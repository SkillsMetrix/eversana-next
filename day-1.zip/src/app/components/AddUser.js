'use client'
import React, { Component } from 'react'

export default class AddUser extends Component {

  addUser=(e)=>{
   e.preventDefault()
    
    const data= e.target.elements.uname.value
 
      this.props.au(data)
  }
  render() {
    return (
      <div>
        <form onSubmit={this.addUser}>
         UserName :<input type='text' name='uname'/> 
         Email :<input type='text' name='email'/> 

        <button>Add</button>
        </form>
       
      </div>
    )
  }
}

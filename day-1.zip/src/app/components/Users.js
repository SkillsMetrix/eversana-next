


import React, { Component } from 'react'
import User from './User'

export default class Users extends Component {
  render() {
    return (
      <div>
        {
          this.props.ud.map((udata)=> <User key={udata} users={udata}/>)
        }
       
       <button disabled={this.props.hasData} onClick={this.props.da}>DeleteAll</button>
      </div>
    )
  }
}

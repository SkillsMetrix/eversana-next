"use client";

import { Component } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Users from "./Users";
import AddUser from "./AddUser";

export default class MainApp extends Component {
  state = {
    headerData: "Welcome to Header",
    userData: [],
  };
  deleteAll=()=>{
    this.setState(()=>{
      return{
        userData:[]
      }
    })
  }
  addUser = (user) => {
    this.setState((prevState) => {
      return {
        userData: prevState.userData.concat(user),
      };
    });
  };
  render() {
    return (
      <div>
        <Header hdata={this.state.headerData} />
        <p>MainApp Comp</p>
        <Users ud={this.state.userData} da={this.deleteAll}
        hasData={!this.state.userData.length > 0}
        />
        <AddUser au={this.addUser} />
        <Footer />
      </div>
    );
  }
}



 function ServerComp(){

    console.log('server app');
    return (
        <div>
        <p>Welcome to Server Comp</p>
        <p>Welcome to NextJS </p>
        <hr/>
         </div>
    )
}
export default ServerComp
 import MainApp from "./components/MainApp";
import ServerComp from "./components/ServerComp";
import styles from "./page.module.css";

export default function Home() {
  return (
    <main className={styles.main}>
      <div className={styles.description}>
      
      <MainApp/>
      <ServerComp/>
        
      </div>
    </main>
  );
}
